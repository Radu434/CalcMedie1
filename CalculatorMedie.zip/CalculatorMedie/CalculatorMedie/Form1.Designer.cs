﻿namespace CalculatorMedie
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnIntroducere = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnCalculeaza = new System.Windows.Forms.Button();
            this.btnSterge = new System.Windows.Forms.Button();
            this.cbTeza = new System.Windows.Forms.CheckBox();
            this.txtTeza = new System.Windows.Forms.TextBox();
            this.lblMedie = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lstNote = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(44, 31);
            this.txtInput.Margin = new System.Windows.Forms.Padding(2);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(135, 20);
            this.txtInput.TabIndex = 0;
            this.txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
            this.txtInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtInput_KeyPress);
            // 
            // btnIntroducere
            // 
            this.btnIntroducere.BackColor = System.Drawing.Color.PaleTurquoise;
            this.btnIntroducere.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnIntroducere.Location = new System.Drawing.Point(270, 31);
            this.btnIntroducere.Margin = new System.Windows.Forms.Padding(2);
            this.btnIntroducere.Name = "btnIntroducere";
            this.btnIntroducere.Size = new System.Drawing.Size(87, 41);
            this.btnIntroducere.TabIndex = 2;
            this.btnIntroducere.Text = "Adauga";
            this.btnIntroducere.UseVisualStyleBackColor = false;
            this.btnIntroducere.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Red;
            this.btnReset.Location = new System.Drawing.Point(270, 196);
            this.btnReset.Margin = new System.Windows.Forms.Padding(2);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(87, 41);
            this.btnReset.TabIndex = 3;
            this.btnReset.Text = "Reseteaza";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnCalculeaza
            // 
            this.btnCalculeaza.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnCalculeaza.Location = new System.Drawing.Point(270, 77);
            this.btnCalculeaza.Margin = new System.Windows.Forms.Padding(2);
            this.btnCalculeaza.Name = "btnCalculeaza";
            this.btnCalculeaza.Size = new System.Drawing.Size(87, 41);
            this.btnCalculeaza.TabIndex = 4;
            this.btnCalculeaza.Text = "Calculeaza";
            this.btnCalculeaza.UseVisualStyleBackColor = false;
            this.btnCalculeaza.Click += new System.EventHandler(this.btnCalculeaza_Click);
            // 
            // btnSterge
            // 
            this.btnSterge.BackColor = System.Drawing.Color.Red;
            this.btnSterge.Location = new System.Drawing.Point(270, 150);
            this.btnSterge.Margin = new System.Windows.Forms.Padding(2);
            this.btnSterge.Name = "btnSterge";
            this.btnSterge.Size = new System.Drawing.Size(87, 41);
            this.btnSterge.TabIndex = 5;
            this.btnSterge.Text = "Sterge";
            this.btnSterge.UseVisualStyleBackColor = false;
            this.btnSterge.Click += new System.EventHandler(this.btnSterge_Click);
            // 
            // cbTeza
            // 
            this.cbTeza.AutoSize = true;
            this.cbTeza.Location = new System.Drawing.Point(44, 323);
            this.cbTeza.Margin = new System.Windows.Forms.Padding(2);
            this.cbTeza.Name = "cbTeza";
            this.cbTeza.Size = new System.Drawing.Size(50, 17);
            this.cbTeza.TabIndex = 6;
            this.cbTeza.Text = "Teza";
            this.cbTeza.UseVisualStyleBackColor = true;
            this.cbTeza.CheckedChanged += new System.EventHandler(this.cbTeza_CheckedChanged);
            // 
            // txtTeza
            // 
            this.txtTeza.Location = new System.Drawing.Point(282, 322);
            this.txtTeza.Margin = new System.Windows.Forms.Padding(2);
            this.txtTeza.Name = "txtTeza";
            this.txtTeza.Size = new System.Drawing.Size(76, 20);
            this.txtTeza.TabIndex = 7;
            this.txtTeza.TextChanged += new System.EventHandler(this.txtTeza_TextChanged);
            this.txtTeza.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTeza_KeyPress);
            // 
            // lblMedie
            // 
            this.lblMedie.AutoSize = true;
            this.lblMedie.BackColor = System.Drawing.Color.Transparent;
            this.lblMedie.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMedie.Location = new System.Drawing.Point(90, 370);
            this.lblMedie.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMedie.Name = "lblMedie";
            this.lblMedie.Size = new System.Drawing.Size(0, 17);
            this.lblMedie.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Introducere note";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Lista Note";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(280, 306);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Nota Teza";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 372);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Media:";
            // 
            // lstNote
            // 
            this.lstNote.FormattingEnabled = true;
            this.lstNote.Location = new System.Drawing.Point(44, 91);
            this.lstNote.Margin = new System.Windows.Forms.Padding(2);
            this.lstNote.Name = "lstNote";
            this.lstNote.Size = new System.Drawing.Size(135, 147);
            this.lstNote.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 410);
            this.Controls.Add(this.lstNote);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMedie);
            this.Controls.Add(this.txtTeza);
            this.Controls.Add(this.cbTeza);
            this.Controls.Add(this.btnSterge);
            this.Controls.Add(this.btnCalculeaza);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnIntroducere);
            this.Controls.Add(this.txtInput);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnIntroducere;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnCalculeaza;
        private System.Windows.Forms.Button btnSterge;
        private System.Windows.Forms.CheckBox cbTeza;
        private System.Windows.Forms.TextBox txtTeza;
        private System.Windows.Forms.Label lblMedie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox lstNote;
    }
}

